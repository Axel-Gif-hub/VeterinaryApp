data class Animal(
    val id: String = "",
    val nombre: String = "",
    val edad: Int = 0,
    val especie: String = "",
    val propietario: String = ""
)
